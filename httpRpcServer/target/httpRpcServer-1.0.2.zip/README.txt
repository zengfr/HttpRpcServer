http://127.0.0.1:8844/?token=1&type=http&cmd=get&args=http://news.baidu.com/

http://127.0.0.1:8844/?token=1&type=pppoestop
http://127.0.0.1:8844/?token=1&type=pppoestart

http://127.0.0.1:8844/?token=1&type=cmd&cmd=dir
http://127.0.0.1:8844/?token=1&type=exec&cmd=netstat -ano